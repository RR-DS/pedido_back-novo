package br.ufpr.sisped.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.ufpr.sisped.model.ItemPedido;

public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long> {

}
